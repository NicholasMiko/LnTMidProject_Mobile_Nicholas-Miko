
public class Main {
	static String productType,productBrand,productName;

	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        	
            do{
                System.out.print("Input Type [Car | Motorcycle] : ");
                productType = scanner.nextLine();
                productType = productType.toUpperCase();
            }while(productType.equals("Car") && productType.equals("productType"));

            if(productType.equals("Car")){
                Car car = new Car();
                do{
                	System.out.print("Input brand [>= 5] : ");
                    productBrand = scanner.nextLine();
                }while(productBrand.length() < 1 || productBrand.length() > 5);
                
                car.inputType(scanner);
                car.inputBrand(scanner);
                car.inputName(scanner);
                car.inputLicense(scanner);
                car.inputTopSpeed(scanner);
                car.inputGasCapacity(scanner);
                car.inputWheel(scanner);
                car.inputEntertainment(scanner);
                System.out.println();                     
               
                    System.out.println("Input brand  : "+car.getBrand);
                    System.out.println("Input name  : " +car.getName());
                    System.out.println("Input License   : " +car.getLicense());
                    System.out.println("Input top speed : " +car.getTopSpeed());
                    System.out.println("Input gas capacity : " +car.getGasCapacity());
                    System.out.println("Input wheel : " +car.getWheel());
                    System.out.println("Input type : " +car.getType());
                    System.out.println("Input entertainment : " +car.getEntertainment));
                    System.out.println("Turning on entertainment system...");
                    
                    
            }else{
                Motorcycle motorcycle = new Motorcycle();
                do{
                	
                    motorcycle.inputType(scanner);
                    motorcycle.inputBrand(scanner);
                    motorcycle.inputName(scanner);
                    motorcycle.inputLicense(scanner);
                    motorcycle.inputTopSpeed(scanner);
                    motorcycle.inputGasCapacity(scanner);
                    motorcycle.inputWheel(scanner);
                    motorcycle.inputEntertainment(scanner);
                    System.out.println();     
                    
                    System.out.println("Input brand  : "+motorcycle.getBrand);
                    System.out.println("Input name  : " +motorcycle.getName());
                    System.out.println("Input License   : " +motorcycle.getLicense());
                    System.out.println("Input top speed : " +motorcycle.getTopSpeed());
                    System.out.println("Input gas capacity : " +motorcycle.getGasCapacity());
                    System.out.println("Input wheel : " +motorcycle.getWheel());
                    System.out.println("Input type : " +motorcycle.getType());
                    System.out.println("Input entertainment : " +motorcycle.getEntertainment));
                    System.out.println("Turning on entertainment system...");
                	
                
                    
                    
                    
        	}
	}
	
}