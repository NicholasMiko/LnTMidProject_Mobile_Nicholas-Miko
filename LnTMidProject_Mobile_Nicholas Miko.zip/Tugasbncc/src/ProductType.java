import java.util.HashMap;
import java.util.Scanner;

abstract class ProductType{
    HashMap<String,Integer> typeprices = new HashMap<String, Integer>();
 

    String[] productTypes = {"Car", "Motorcycle"};
    String[] productType = {"SUV", "Supecar", "Minivan"};
    String[] Wheel = 